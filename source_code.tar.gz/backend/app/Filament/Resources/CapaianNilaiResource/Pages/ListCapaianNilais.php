<?php

namespace App\Filament\Resources\CapaianNilaiResource\Pages;

use App\Filament\Resources\CapaianNilaiResource;
use Filament\Resources\Pages\ListRecords;

class ListCapaianNilais extends ListRecords
{
    protected static string $resource = CapaianNilaiResource::class;
}
