<?php

namespace App\Filament\Resources\NilaiSpiritualResource\Pages;

use App\Filament\Resources\NilaiSpiritualResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNilaiSpiritual extends CreateRecord
{
    protected static string $resource = NilaiSpiritualResource::class;
}
