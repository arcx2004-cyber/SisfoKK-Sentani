<?php

namespace App\Filament\Resources\JadwalGuruResource\Pages;

use App\Filament\Resources\JadwalGuruResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJadwalGuru extends CreateRecord
{
    protected static string $resource = JadwalGuruResource::class;
}
