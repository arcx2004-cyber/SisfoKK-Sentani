<?php

namespace App\Filament\Resources\KonselingResource\Pages;

use App\Filament\Resources\KonselingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKonseling extends CreateRecord
{
    protected static string $resource = KonselingResource::class;
}
