<?php

namespace App\Filament\Resources\NilaiTujuanPembelajaranResource\Pages;

use App\Filament\Resources\NilaiTujuanPembelajaranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNilaiTujuanPembelajaran extends CreateRecord
{
    protected static string $resource = NilaiTujuanPembelajaranResource::class;
}
