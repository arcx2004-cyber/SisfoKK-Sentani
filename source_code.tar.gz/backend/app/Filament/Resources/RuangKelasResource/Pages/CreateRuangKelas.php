<?php

namespace App\Filament\Resources\RuangKelasResource\Pages;

use App\Filament\Resources\RuangKelasResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRuangKelas extends CreateRecord
{
    protected static string $resource = RuangKelasResource::class;
}
