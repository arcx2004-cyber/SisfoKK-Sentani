<?php

namespace App\Filament\Resources\InputRaporSmpResource\Pages;

use App\Filament\Resources\InputRaporSmpResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInputRaporSmp extends CreateRecord
{
    protected static string $resource = InputRaporSmpResource::class;
}
