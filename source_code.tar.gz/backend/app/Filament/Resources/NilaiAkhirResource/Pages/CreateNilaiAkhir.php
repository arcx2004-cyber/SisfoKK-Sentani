<?php

namespace App\Filament\Resources\NilaiAkhirResource\Pages;

use App\Filament\Resources\NilaiAkhirResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNilaiAkhir extends CreateRecord
{
    protected static string $resource = NilaiAkhirResource::class;
}
