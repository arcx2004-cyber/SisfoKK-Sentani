<?php

namespace App\Filament\Resources\CapaianPembelajaranResource\Pages;

use App\Filament\Resources\CapaianPembelajaranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCapaianPembelajaran extends CreateRecord
{
    protected static string $resource = CapaianPembelajaranResource::class;
}
