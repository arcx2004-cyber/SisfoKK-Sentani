<?php

namespace App\Filament\Resources\PpdbSettingResource\Pages;

use App\Filament\Resources\PpdbSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePpdbSetting extends CreateRecord
{
    protected static string $resource = PpdbSettingResource::class;
}
