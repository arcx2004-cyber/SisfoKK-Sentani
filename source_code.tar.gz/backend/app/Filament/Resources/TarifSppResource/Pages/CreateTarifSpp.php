<?php

namespace App\Filament\Resources\TarifSppResource\Pages;

use App\Filament\Resources\TarifSppResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTarifSpp extends CreateRecord
{
    protected static string $resource = TarifSppResource::class;
}
