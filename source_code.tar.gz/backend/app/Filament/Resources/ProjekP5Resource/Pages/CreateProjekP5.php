<?php

namespace App\Filament\Resources\ProjekP5Resource\Pages;

use App\Filament\Resources\ProjekP5Resource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProjekP5 extends CreateRecord
{
    protected static string $resource = ProjekP5Resource::class;
}
