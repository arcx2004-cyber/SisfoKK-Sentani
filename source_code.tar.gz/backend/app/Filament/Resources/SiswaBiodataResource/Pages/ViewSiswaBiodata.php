<?php

namespace App\Filament\Resources\SiswaBiodataResource\Pages;

use App\Filament\Resources\SiswaBiodataResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewSiswaBiodata extends ViewRecord
{
    protected static string $resource = SiswaBiodataResource::class;
}
