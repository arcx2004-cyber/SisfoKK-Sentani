<?php

namespace App\Filament\Resources\RaportResource\Pages;

use App\Filament\Resources\RaportResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRaport extends CreateRecord
{
    protected static string $resource = RaportResource::class;
}
