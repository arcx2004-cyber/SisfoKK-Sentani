<?php

namespace App\Filament\Resources\InputNilaiResource\Pages;

use App\Filament\Resources\InputNilaiResource;
use Filament\Resources\Pages\Page;

class InputNilai extends Page
{
    protected static string $resource = InputNilaiResource::class;

    protected static string $view = 'filament.resources.input-nilai-resource.pages.input-nilai';
}
