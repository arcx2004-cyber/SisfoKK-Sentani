<?php

namespace App\Filament\Resources\RapbsResource\Pages;

use App\Filament\Resources\RapbsResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditRapbs extends EditRecord
{
    protected static string $resource = RapbsResource::class;
}
