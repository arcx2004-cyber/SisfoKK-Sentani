<?php

namespace App\Filament\Resources\RapbsResource\Pages;

use App\Filament\Resources\RapbsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRapbs extends CreateRecord
{
    protected static string $resource = RapbsResource::class;
}
