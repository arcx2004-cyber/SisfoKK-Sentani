<?php

namespace App\Filament\Resources\AbsensiSiswaResource\Pages;

use App\Filament\Resources\AbsensiSiswaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAbsensiSiswa extends CreateRecord
{
    protected static string $resource = AbsensiSiswaResource::class;
}
