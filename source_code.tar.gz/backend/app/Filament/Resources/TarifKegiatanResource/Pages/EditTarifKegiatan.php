<?php

namespace App\Filament\Resources\TarifKegiatanResource\Pages;

use App\Filament\Resources\TarifKegiatanResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditTarifKegiatan extends EditRecord
{
    protected static string $resource = TarifKegiatanResource::class;
}
