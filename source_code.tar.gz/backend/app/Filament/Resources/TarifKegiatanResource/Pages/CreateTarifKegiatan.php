<?php

namespace App\Filament\Resources\TarifKegiatanResource\Pages;

use App\Filament\Resources\TarifKegiatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTarifKegiatan extends CreateRecord
{
    protected static string $resource = TarifKegiatanResource::class;
}
