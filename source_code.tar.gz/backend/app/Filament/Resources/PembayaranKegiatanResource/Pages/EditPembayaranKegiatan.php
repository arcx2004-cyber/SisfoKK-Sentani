<?php

namespace App\Filament\Resources\PembayaranKegiatanResource\Pages;

use App\Filament\Resources\PembayaranKegiatanResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditPembayaranKegiatan extends EditRecord
{
    protected static string $resource = PembayaranKegiatanResource::class;
}
