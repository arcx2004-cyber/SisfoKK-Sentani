<?php

namespace App\Filament\Resources\PembayaranKegiatanResource\Pages;

use App\Filament\Resources\PembayaranKegiatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePembayaranKegiatan extends CreateRecord
{
    protected static string $resource = PembayaranKegiatanResource::class;
}
