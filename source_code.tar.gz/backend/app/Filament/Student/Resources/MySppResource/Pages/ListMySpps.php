<?php

namespace App\Filament\Student\Resources\MySppResource\Pages;

use App\Filament\Student\Resources\MySppResource;
use Filament\Resources\Pages\ListRecords;

class ListMySpps extends ListRecords
{
    protected static string $resource = MySppResource::class;
}
