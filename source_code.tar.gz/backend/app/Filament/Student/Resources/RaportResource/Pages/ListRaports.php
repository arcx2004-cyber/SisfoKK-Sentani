<?php

namespace App\Filament\Student\Resources\RaportResource\Pages;

use App\Filament\Student\Resources\RaportResource;
use Filament\Resources\Pages\ListRecords;

class ListRaports extends ListRecords
{
    protected static string $resource = RaportResource::class;
}
