<x-filament-panels::page>
    {{ $this->form }}
    
    {{ $this->table }}
</x-filament-panels::page>
